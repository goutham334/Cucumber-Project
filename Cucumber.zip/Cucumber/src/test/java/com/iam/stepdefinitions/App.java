package com.iam.stepdefinitions;

public class App {

	public static void main(String[] args) {
		
		
		
		String str = "$6000";
		String v = str.substring(1);
		
		System.out.println(v);
		

	} 

}
